Terraform Notes.

Observations

Terraform having issues with Nat-gateway association not getting routed properly in the private subnet, 
Upon investigation , the NAT Gateway config was wrong and also had to fix the subnet routing to allow traffic from the alb , 

Created a different security group to grant access from the internet to the load balancer and also updated traffic from the other security group.

Due to a cycle error when allowing traffic from the security group, I used the VPC ID instead to confine traffic since the resources all share the same security group.

Updated Load balancer to send logs to bucket and also made bucket name dynamic by generating a  random prefix. Alb access logs are already gzipped.

Solution steps taken

Create route binding 0.0.0.0 to the nat gateway
in the private subnet

Create new bucket and configure alb to log access and update policy.

Update health check to ping root rather than error.html

Create additional security group and Update existing.

Added auto scaling policy using target tracking to scale and adjust based on CPU Utilization at 40%.

Updated Autoscaling group to use ELB health check rather than EC2 to make sure its up and also refresh after 5mins of no being healthy.